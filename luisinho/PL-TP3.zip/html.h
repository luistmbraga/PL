#ifndef __HTML_H__
#define __HTML_H__
#define _GNU_SOURCE

#include <stdlib.h>
#include <stdio.h>
#include <string.h>


char* constroi_pagcreditos();

void constroi_pagina();

#endif